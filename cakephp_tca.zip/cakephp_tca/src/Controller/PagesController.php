<?php
namespace App\Controller;

class PagesController extends AppController
{

    public function index() {

	}
}
